import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class htmlReader {
	
	public static void main(String[] args) throws IOException {
	    
	    File dir = new File("res/report-acrobat-rest/");
	    File [] directoryListing = dir.listFiles();
	    if(directoryListing != null){
	    	
	    	String filename = "res/acrobat-rest.xls" ;
		    HSSFWorkbook workbook = new HSSFWorkbook();
	        HSSFSheet sheet = workbook.createSheet("FirstSheet"); 
	        
	        HSSFRow rowhead = sheet.createRow((short)0);
	        rowhead.createCell(0).setCellValue("Total");
	        rowhead.createCell(1).setCellValue("Spurious");
	        rowhead.createCell(2).setCellValue("Confused");
	        rowhead.createCell(3).setCellValue("Lost");
	        rowhead.createCell(4).setCellValue("CER");
	        rowhead.createCell(5).setCellValue("WER");
	        rowhead.createCell(6).setCellValue("WER order independent");
	        
	    	for(int i = 0; i < directoryListing.length; i++){
	    		Document doc = Jsoup.parse(directoryListing[i], "UTF-8");
	    		ArrayList<Integer> total = new ArrayList<Integer>();
	            ArrayList<Integer> spurious = new ArrayList<Integer>();
	            ArrayList<Integer> confused = new ArrayList<Integer>();
	            ArrayList<Integer> lost = new ArrayList<Integer>();
	            
	            Elements tables = doc.getElementsByTag("table");
	            Element genResults = tables.get(0);
	            Element errorRates = tables.get(2);
	            
	            String cer = genResults.getElementsByTag("td").get(1).text();
	            String wer = genResults.getElementsByTag("td").get(3).text();
	            String weroi = genResults.getElementsByTag("td").get(5).text();
	            
	            Elements rows = errorRates.getElementsByTag("tr");
	            
	            for(int j = 1; j < rows.size(); j++){
	            	total.add(Integer.parseInt(rows.get(j).getElementsByTag("td").get(2).text()));
	            	spurious.add(Integer.parseInt(rows.get(j).getElementsByTag("td").get(3).text()));
	            	confused.add(Integer.parseInt(rows.get(j).getElementsByTag("td").get(4).text()));
	            	lost.add(Integer.parseInt(rows.get(j).getElementsByTag("td").get(5).text()));
	            }
	            
	            int countTotal = 0;
	            int countSpurious = 0;
	            int countConfused = 0;
	            int countLost = 0;
	            
	            for(int k = 0; k < total.size(); k++){
	            	countTotal += total.get(k);
	            	countSpurious += spurious.get(k);
	            	countConfused += confused.get(k);
	            	countLost += lost.get(k);
	            }
	            //Child finished
	            /*
	            System.out.println("Filename: " + directoryListing[i].getName());
	            System.out.println("Cer: " + cer);
	            System.out.println("Wer: " + wer);
	            System.out.println("Wer (order independent): " + weroi);
	            System.out.println("Total: " + countTotal);
	            System.out.println("Spurious: " + countSpurious);
	            System.out.println("Confused: " + countConfused);
	            System.out.println("Lost: " + countLost);
	            System.out.println("########");
	            */
	            
	            HSSFRow row = sheet.createRow((short)i);
	            row.createCell(0).setCellValue(countTotal);
	            row.createCell(1).setCellValue(countSpurious);
	            row.createCell(2).setCellValue(countConfused);
	            row.createCell(3).setCellValue(countLost);
	            row.createCell(4).setCellValue(cer);
	            row.createCell(5).setCellValue(wer);
	            row.createCell(6).setCellValue(weroi);
	            
	    	}
	    	FileOutputStream fileOut = new FileOutputStream(filename);
            workbook.write(fileOut);
            fileOut.close();
            System.out.println("Your excel file has been generated!");
	    }   
        
	}
}
